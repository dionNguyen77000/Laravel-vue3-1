<?php

namespace App\Policies;

use App\Models\Post;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PostPolicy
{
    use HandlesAuthorization;

    public function delete(User $user, Post $post)
    {
        return (int)$user->id === (int)$post->user_id;
    }

    /**
     * Create a new policy instance.
     *
     * @return void
     */
   
}
