@extends('layouts.app_vue')

@section('content')

    <div id="app">
    
        <App_Stock> </App_Stock>
        
    </div>

@endsection