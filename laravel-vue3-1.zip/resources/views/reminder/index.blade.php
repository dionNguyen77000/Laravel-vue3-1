@extends('layouts.app')

@section('content')
        <div id="app">
            {{-- <App> </App> --}}
        </div>
@endsection