module.exports = new Vue()
