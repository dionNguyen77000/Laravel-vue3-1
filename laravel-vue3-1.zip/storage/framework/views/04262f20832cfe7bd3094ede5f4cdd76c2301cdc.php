<?php $attributes = $attributes->exceptProps(['post' => $post]); ?>
<?php foreach (array_filter((['post' => $post]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="mb-3 p-3 border border-indigo-600 rounded-md shadow-md">
    <a href="<?php echo e(route('users.posts', $post->user)); ?>" class="font-bold text-lg"><?php echo e($post->user->name); ?></a> 
    <span class="text-gray-600 text-sm"><?php echo e($post->created_at->diffForHumans()); ?></span>
    <p class="mb-1 text-xl"><?php echo e($post->body); ?></p>
    
    

    
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$post)): ?>
            <form action="<?php echo e(route('posts.destroy',$post)); ?>" method="post" class="mr-1">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="py-1 px-2 shadow-md rounded-full bg-red-400 text-white text-sm hover:bg-red-700 focus:outline-none active:bg-green-crimson">
                     <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                </button>
            </form>
        <?php endif; ?>
     
    <div class="flex items-center">
        <?php if(auth()->guard()->check()): ?> 
        <?php if(!$post->likedBy(auth()->user())): ?>
            <form action="<?php echo e(route('posts.likes',$post)); ?>" method="post" class="mr-1">
                <?php echo csrf_field(); ?>
                <button type="submit" class="text-blue-500">Like</button>
            </form> 
        <?php else: ?>
            <form action="<?php echo e(route('posts.likes',$post)); ?>" method="post" class="mr-1">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="text-blue-500">Unlike</button>
            </form>
        <?php endif; ?>
        <?php endif; ?>
            <span><?php echo e($post->likes->count()); ?> <?php echo e(Str::plural('like',$post->likes->count())); ?></span>
       
    </div>
</div><?php /**PATH C:\Users\localboss\Desktop\Laravel\laravel-vue3-1\resources\views/components/post.blade.php ENDPATH**/ ?>