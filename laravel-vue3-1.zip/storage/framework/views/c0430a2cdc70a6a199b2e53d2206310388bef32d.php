

<?php $__env->startSection('content'); ?>

    <div id="app">
    
        <App_Stock> </App_Stock>
        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_vue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\localboss\Desktop\Laravel\laravel-vue3-1\resources\views/welcome.blade.php ENDPATH**/ ?>