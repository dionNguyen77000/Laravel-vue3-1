<?php
symlink('/home/dionhana11/laravel-vue3-1-backend/storage/app/public','/home/dionhana11/backend.goldenloryarrabilba.com.au/storage');
